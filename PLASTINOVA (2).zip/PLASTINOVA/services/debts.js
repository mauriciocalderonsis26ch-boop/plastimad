/* ========== Servicio: Deudas — Bmaru ERP ========== */
const { makeCrudService } = require('./base');

function makeDebtsService(db) {
  const crud = makeCrudService(db, 'debts', ['person', 'description', 'amount', 'paid', 'due_date']);
  return { ...crud };
}

module.exports = { makeDebtsService };
