/* ========== Servicio: Productos — Bmaru ERP ========== */
const { makeCrudService } = require('./base');

function makeProductsService(db) {
  const crud = makeCrudService(db, 'products', [
    'name', 'category', 'unit', 'cost', 'price', 'stock', 'min_stock', 'active',
  ]);

  function list() {
    return crud.list();
  }

  function getById(id) {
    return crud.getById(id);
  }

  function create(data) {
    return crud.create(data);
  }

  function update(id, data) {
    return crud.update(id, data);
  }

  function remove(id) {
    return crud.remove(id);
  }

  function adjustStock(id, delta, movementType, note) {
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!product) {
      const err = new Error('Producto no encontrado.');
      err.status = 404;
      throw err;
    }
    const newStock = Number(product.stock) + Number(delta);
    if (newStock < 0) {
      const err = new Error('Stock insuficiente.');
      err.status = 400;
      throw err;
    }
    db.prepare('UPDATE products SET stock = ? WHERE id = ?').run(newStock, id);
    db.prepare(
      'INSERT INTO inventory_movements (product_id, movement_type, quantity, note) VALUES (?, ?, ?, ?)'
    ).run(id, movementType, Math.abs(Number(delta)), note);
    return db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  }

  return { list, getById, create, update, remove, adjustStock };
}

module.exports = { makeProductsService };
