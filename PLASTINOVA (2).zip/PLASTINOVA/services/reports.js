/* ========== Servicio: Reportes — Bmaru ERP ========== */

function makeReportsService(db) {
  function getSummary() {
    const byMonth = db.prepare(
      "SELECT strftime('%Y-%m', created_at) month, SUM(total) total FROM sales GROUP BY month ORDER BY month DESC LIMIT 12"
    ).all();
    const expenseByCategory = db.prepare(
      'SELECT category, SUM(amount) total FROM expenses GROUP BY category ORDER BY total DESC'
    ).all();
    return { byMonth, expenseByCategory };
  }

  return { getSummary };
}

module.exports = { makeReportsService };
