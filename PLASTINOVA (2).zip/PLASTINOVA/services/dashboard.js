/* ========== Servicio: Dashboard — Bmaru ERP ========== */

function makeDashboardService(db) {
  function getSummary() {
    const sales = db.prepare(
      "SELECT COALESCE(SUM(total),0) total FROM sales WHERE date(created_at) = date('now','localtime')"
    ).get().total;
    const purchases = db.prepare(
      "SELECT COALESCE(SUM(total),0) total FROM purchases WHERE date(created_at) = date('now','localtime')"
    ).get().total;
    const expenses = db.prepare(
      "SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE date(created_at) = date('now','localtime')"
    ).get().total;
    const stockValue = db.prepare('SELECT COALESCE(SUM(stock * cost),0) total FROM products').get().total;
    const products = db.prepare('SELECT COUNT(*) count FROM products').get().count;
    const lowStock = db.prepare('SELECT COUNT(*) count FROM products WHERE stock <= min_stock').get().count;
    const outstanding = db.prepare('SELECT COALESCE(SUM(amount - paid),0) total FROM debts').get().total;

    return {
      sales,
      purchases,
      expenses,
      stockValue,
      products,
      lowStock,
      outstanding,
      estimatedBalance: sales - purchases - expenses,
    };
  }

  return { getSummary };
}

module.exports = { makeDashboardService };
