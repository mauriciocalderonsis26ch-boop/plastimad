/* ========== Servicio: Proveedores — Bmaru ERP ========== */
const { makeCrudService } = require('./base');

function makeSuppliersService(db) {
  const crud = makeCrudService(db, 'suppliers', ['name', 'phone', 'email', 'address']);
  return { ...crud };
}

module.exports = { makeSuppliersService };
