/* ========== Servicio base CRUD — Bmaru ERP ========== */

function makeCrudService(db, table, fields) {
  function list() {
    return db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all();
  }

  function getById(id) {
    return db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
  }

  function create(data) {
    const values = fields.map((f) => data[f] ?? '');
    const placeholders = fields.map(() => '?').join(',');
    const result = db.prepare(
      `INSERT INTO ${table} (${fields.join(',')}) VALUES (${placeholders})`
    ).run(...values);
    return getById(result.lastInsertRowid);
  }

  function update(id, data) {
    // Solo actualiza campos enviados (PUT parcial)
    const updates = fields.filter((f) => f in data);
    if (updates.length === 0) {
      const err = new Error('No hay campos para actualizar.');
      err.status = 400;
      throw err;
    }
    const values = updates.map((f) => data[f]);
    const set = updates.map((f) => `${f} = ?`).join(',');
    const result = db.prepare(
      `UPDATE ${table} SET ${set} WHERE id = ?`
    ).run(...values, id);
    if (!result.changes) {
      const err = new Error('Registro no encontrado.');
      err.status = 404;
      throw err;
    }
    return getById(id);
  }

  function remove(id) {
    const result = db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
    if (!result.changes) {
      const err = new Error('Registro no encontrado.');
      err.status = 404;
      throw err;
    }
    return { ok: true };
  }

  return { list, getById, create, update, remove };
}

module.exports = { makeCrudService };
