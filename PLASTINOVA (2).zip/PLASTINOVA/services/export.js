/* ========== Servicio: Exportación — Bmaru ERP ========== */

function makeExportService(db) {
  function getProductsCsv() {
    const rows = db.prepare('SELECT id, name, category, unit, cost, price, stock, min_stock FROM products ORDER BY name').all();
    const esc = (v) => '"' + String(v ?? '').replace(/"/g, '""') + '"';
    const csv = [
      'id,nombre,categoria,unidad,costo,precio,stock,stock_minimo',
      ...rows.map((r) => Object.values(r).map(esc).join(',')),
    ].join('\n');
    return '\uFEFF' + csv;
  }

  return { getProductsCsv };
}

module.exports = { makeExportService };
