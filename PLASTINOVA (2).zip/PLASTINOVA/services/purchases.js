/* ========== Servicio: Compras — Bmaru ERP ========== */

function makePurchasesService(db) {
  function list() {
    return db.prepare(
      `SELECT p.*, s.name supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id ORDER BY p.id DESC`
    ).all();
  }

  function getById(id) {
    return db.prepare('SELECT * FROM purchases WHERE id = ?').get(id);
  }

  function create({ supplier_id = null, items, notes = '' }) {
    if (!Array.isArray(items) || !items.length) {
      const err = new Error('Agrega al menos un producto.');
      err.status = 400;
      throw err;
    }

    return db.transaction(() => {
      let total = 0;
      const normalized = items.map((item) => {
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.product_id);
        const quantity = Number(item.quantity);
        const unit_cost = Number(item.unit_cost ?? product?.cost);
        if (!product || quantity <= 0 || unit_cost < 0) {
          throw new Error('Producto, cantidad o costo inválido.');
        }
        const subtotal = quantity * unit_cost;
        total += subtotal;
        return { product, quantity, unit_cost, subtotal };
      });

      const purchase = db.prepare(
        'INSERT INTO purchases (supplier_id, total, notes) VALUES (?, ?, ?)'
      ).run(supplier_id || null, total, notes);

      for (const item of normalized) {
        db.prepare(
          'INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost, subtotal) VALUES (?, ?, ?, ?, ?)'
        ).run(purchase.lastInsertRowid, item.product.id, item.quantity, item.unit_cost, item.subtotal);
        db.prepare('UPDATE products SET stock = stock + ?, cost = ? WHERE id = ?').run(item.quantity, item.unit_cost, item.product.id);
        db.prepare(
          'INSERT INTO inventory_movements (product_id, movement_type, quantity, note) VALUES (?, ?, ?, ?)'
        ).run(item.product.id, 'ENTRADA', item.quantity, 'Compra #' + purchase.lastInsertRowid);
      }

      return purchase.lastInsertRowid;
    });
  }

  return { list, getById, create };
}

module.exports = { makePurchasesService };
