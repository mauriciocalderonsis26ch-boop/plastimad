/* ========== Servicio: Clientes — Bmaru ERP ========== */
const { makeCrudService } = require('./base');

function makeClientsService(db) {
  const crud = makeCrudService(db, 'clients', ['name', 'phone', 'email', 'address']);
  return { ...crud };
}

module.exports = { makeClientsService };
