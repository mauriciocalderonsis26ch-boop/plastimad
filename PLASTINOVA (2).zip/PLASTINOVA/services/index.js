/* ========== Índice de servicios — Bmaru ERP ========== */

function loadServices(db) {
  const { makeProductsService } = require('./products');
  const { makeClientsService } = require('./clients');
  const { makeSuppliersService } = require('./suppliers');
  const { makeEmployeesService } = require('./employees');
  const { makeExpensesService } = require('./expenses');
  const { makeDebtsService } = require('./debts');
  const { makeSalesService } = require('./sales');
  const { makePurchasesService } = require('./purchases');
  const { makeDashboardService } = require('./dashboard');
  const { makeReportsService } = require('./reports');
  const { makeMovementsService } = require('./movements');
  const { makeExportService } = require('./export');

  return {
    products: makeProductsService(db),
    clients: makeClientsService(db),
    suppliers: makeSuppliersService(db),
    employees: makeEmployeesService(db),
    expenses: makeExpensesService(db),
    debts: makeDebtsService(db),
    sales: makeSalesService(db),
    purchases: makePurchasesService(db),
    dashboard: makeDashboardService(db),
    reports: makeReportsService(db),
    movements: makeMovementsService(db),
    export: makeExportService(db),
  };
}

module.exports = { loadServices };
