/* ========== Servicio: Ventas — Bmaru ERP ========== */
const bcrypt = require('bcryptjs');

function makeSalesService(db) {
  function list() {
    return db.prepare(
      `SELECT s.*, c.name AS client_name FROM sales s LEFT JOIN clients c ON c.id = s.client_id ORDER BY s.id DESC`
    ).all();
  }

  function getById(id) {
    return db.prepare('SELECT * FROM sales WHERE id = ?').get(id);
  }

  function getItems(saleId) {
    return db.prepare(
      `SELECT si.*, p.name product_name FROM sale_items si JOIN products p ON p.id = si.product_id WHERE si.sale_id = ?`
    ).all(saleId);
  }

  function create({ client_id = null, items, paid = 0, notes = '' }) {
    if (!Array.isArray(items) || !items.length) {
      const err = new Error('Agrega al menos un producto.');
      err.status = 400;
      throw err;
    }

    return db.transaction(() => {
      let total = 0;
      const normalized = items.map((item) => {
        const product = db.prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(item.product_id);
        const quantity = Number(item.quantity);
        if (!product || !Number.isFinite(quantity) || quantity <= 0) {
          throw new Error('Producto o cantidad inválida.');
        }
        if (product.stock < quantity) {
          throw new Error('Stock insuficiente para: ' + product.name);
        }
        const unit_price = Number(item.unit_price ?? product.price);
        const subtotal = quantity * unit_price;
        total += subtotal;
        return { product, quantity, unit_price, subtotal };
      });

      const sale = db.prepare(
        'INSERT INTO sales (client_id, total, paid, notes) VALUES (?, ?, ?, ?)'
      ).run(client_id || null, total, Number(paid), notes);

      for (const item of normalized) {
        db.prepare(
          'INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)'
        ).run(sale.lastInsertRowid, item.product.id, item.quantity, item.unit_price, item.subtotal);
        db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(item.quantity, item.product.id);
        db.prepare(
          'INSERT INTO inventory_movements (product_id, movement_type, quantity, note) VALUES (?, ?, ?, ?)'
        ).run(item.product.id, 'SALIDA', item.quantity, 'Venta #' + sale.lastInsertRowid);
      }

      if (Number(paid) < total) {
        const clientName = client_id
          ? (db.prepare('SELECT name FROM clients WHERE id = ?').get(client_id)?.name || 'Cliente')
          : 'Cliente';
        db.prepare(
          'INSERT INTO debts (person, description, amount, paid) VALUES (?, ?, ?, ?)'
        ).run(clientName, 'Saldo de venta #' + sale.lastInsertRowid, total, Number(paid));
      }

      return sale.lastInsertRowid;
    });
  }

  return { list, getById, getItems, create };
}

module.exports = { makeSalesService };
