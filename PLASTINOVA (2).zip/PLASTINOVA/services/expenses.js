/* ========== Servicio: Gastos — Bmaru ERP ========== */
const { makeCrudService } = require('./base');

function makeExpensesService(db) {
  const crud = makeCrudService(db, 'expenses', ['description', 'category', 'amount']);
  return { ...crud };
}

module.exports = { makeExpensesService };
