/* ========== Servicio: Empleados — Bmaru ERP ========== */
const { makeCrudService } = require('./base');

function makeEmployeesService(db) {
  const crud = makeCrudService(db, 'employees', ['name', 'position', 'phone', 'salary']);
  return { ...crud };
}

module.exports = { makeEmployeesService };
