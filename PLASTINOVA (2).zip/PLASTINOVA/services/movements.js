/* ========== Servicio: Movimientos de inventario — Bmaru ERP ========== */

function makeMovementsService(db) {
  function list() {
    return db.prepare(
      `SELECT m.*, p.name product_name FROM inventory_movements m JOIN products p ON p.id = m.product_id ORDER BY m.id DESC LIMIT 200`
    ).all();
  }

  return { list };
}

module.exports = { makeMovementsService };
