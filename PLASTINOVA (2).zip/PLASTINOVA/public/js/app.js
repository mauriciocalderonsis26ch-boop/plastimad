const $ = s => document.querySelector(s);
let token = localStorage.getItem('plastinova_token') || '';
let currentView = 'dashboard';
let editing = null;
let currentRows = [];
let activeAbort = null;
let renderSeq = 0;
let logoutTimer = null;

const titles = {dashboard:'Resumen general',products:'Productos e inventario',clients:'Clientes',suppliers:'Proveedores',employees:'Empleados',sales:'Ventas',purchases:'Compras',expenses:'Gastos',debts:'Deudas',movements:'Movimientos de inventario',reports:'Reportes'};
const configs = {
  products:{label:'producto',endpoint:'products',fields:[['name','Nombre','text',true],['category','Categoría','text'],['unit','Unidad','text'],['cost','Costo (Bs.)','number'],['price','Precio de venta (Bs.)','number'],['stock','Stock actual','number'],['min_stock','Stock mínimo','number']]},
  clients:{label:'cliente',endpoint:'clients',fields:[['name','Nombre completo','text',true],['phone','Teléfono','text'],['email','Correo','email'],['address','Dirección','text']]},
  suppliers:{label:'proveedor',endpoint:'suppliers',fields:[['name','Empresa / nombre','text',true],['phone','Teléfono','text'],['email','Correo','email'],['address','Dirección','text']]},
  employees:{label:'empleado',endpoint:'employees',fields:[['name','Nombre completo','text',true],['position','Cargo','text'],['phone','Teléfono','text'],['salary','Salario (Bs.)','number']]},
  expenses:{label:'gasto',endpoint:'expenses',fields:[['description','Descripción','text',true],['category','Categoría','text'],['amount','Importe (Bs.)','number',true]]},
  debts:{label:'deuda',endpoint:'debts',fields:[['person','Persona / empresa','text',true],['description','Descripción','text'],['amount','Monto total (Bs.)','number',true],['paid','Monto pagado (Bs.)','number'],['due_date','Fecha de vencimiento','date']]}
};

function jwtPayload(t){try{return JSON.parse(atob(t.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));}catch{return null;}}
function tokenExpired(t){const p=jwtPayload(t);return !p||!p.exp||p.exp*1000<=Date.now();}

function setLoading(on){$('#loading').classList.toggle('hidden',!on);}

async function api(url, options={}) {
  const method = (options.method || 'GET').toUpperCase();
  const headers = Object.assign({'Content-Type':'application/json'}, options.headers || {});
  if (token) headers.Authorization = 'Bearer ' + token;
  const init = Object.assign({}, options, {headers});
  if (!init.signal && method === 'GET' && activeAbort) init.signal = activeAbort.signal;
  const response = await fetch('/api' + url, init);
  if (!response.ok) {
    let data = {};
    const ct = response.headers.get('content-type') || '';
    if (ct.includes('application/json')) { try { data = await response.json(); } catch {} }
    const msg = data.error || (response.status === 401 ? 'Tu sesión expiró. Inicia sesión de nuevo.' : 'Error ' + response.status + (response.statusText ? ' (' + response.statusText + ')' : ''));
    if (response.status === 401) { toast(msg); logout(); }
    throw new Error(msg);
  }
  if (response.headers.get('content-type')?.includes('application/json')) return response.json();
  return response.text();
}
function money(n){return 'Bs. ' + Number(n||0).toLocaleString('es-BO',{minimumFractionDigits:2,maximumFractionDigits:2});}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(el._t);el._t=setTimeout(()=>el.classList.remove('show'),2800);}
function showLogin(){ $('#login-screen').classList.remove('hidden'); $('#app-shell').classList.add('hidden'); }
function showApp(){ $('#login-screen').classList.add('hidden'); $('#app-shell').classList.remove('hidden'); $('#today').textContent=new Date().toLocaleDateString('es-BO'); }
function logout(){token='';localStorage.removeItem('plastinova_token');clearTimeout(logoutTimer);logoutTimer=null;if(activeAbort){activeAbort.abort();activeAbort=null;}showLogin();}
function scheduleExpiry(t){
  const p=jwtPayload(t);if(!p||!p.exp)return;
  const ms=p.exp*1000-Date.now();clearTimeout(logoutTimer);
  if(ms<=0)return logout();
  logoutTimer=setTimeout(()=>{toast('Tu sesión expiró. Inicia sesión de nuevo.');logout();},Math.min(ms,2147483647));
}
$('#login-form').addEventListener('submit',async e=>{
  e.preventDefault(); $('#login-error').textContent='';
  const data=Object.fromEntries(new FormData(e.target).entries());
  const btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;
  try{const result=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(r=>r.json());if(!result.token)throw new Error(result.error||'No se pudo iniciar sesión.');token=result.token;localStorage.setItem('plastinova_token',token);$('#whoami').textContent=result.user.username;scheduleExpiry(token);showApp();navigate('dashboard');}
  catch(err){$('#login-error').textContent=err.message;}
  finally{btn.disabled=false;}
});
$('#logout').addEventListener('click',logout);
$('#nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b)navigate(b.dataset.view);});
function navigate(view){currentView=view;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));$('#page-title').textContent=titles[view]||view;render();}
async function render(){
  const seq=++renderSeq;
  if(activeAbort)activeAbort.abort();
  activeAbort=new AbortController();
  setLoading(true);
  $('#view').classList.add('view-fade');
  try{
    if(currentView==='dashboard')await renderDashboard();
    else if(configs[currentView])await renderCrud(currentView);
    else if(currentView==='sales')await renderSales();
    else if(currentView==='purchases')await renderPurchases();
    else if(currentView==='movements')await renderMovements();
    else if(currentView==='reports')await renderReports();
  }catch(e){
    if(e && e.name==='AbortError')return;
    $('#view').innerHTML='<div class="panel error">'+esc(e.message)+'</div>';
  }finally{if(seq===renderSeq)setLoading(false);}
}
function sparkline(values){
  const max=Math.max(...values,1);
  return values.map((v,i)=>'<div class="spark-bar" style="--h:'+(v/max*100)+'%;--i:'+i+';"><div class="spark-fill"></div></div>').join('');
}
async function renderDashboard(){
  const d=await api('/dashboard');
  const metrics=[
    {label:'Ventas de hoy',value:money(d.sales),icon:'↗',color:'green',note:'Ingresos del día',spark:[20,45,30,60,40,80,Math.round(d.sales/10||0)]},
    {label:'Compras de hoy',value:money(d.purchases),icon:'↙',color:'blue',note:'Entradas de mercadería',spark:[10,35,25,50,35,70,Math.round(d.purchases/10||0)]},
    {label:'Gastos de hoy',value:money(d.expenses),icon:'−',color:'red',note:'Egresos operativos',spark:[15,25,20,40,30,55,Math.round(d.expenses/10||0)]},
    {label:'Balance estimado',value:money(d.estimatedBalance),icon:'◈',color:d.estimatedBalance>=0?'green':'red',note:'Ventas menos compras y gastos',spark:[0,0,0,0,0,0,Math.round(d.estimatedBalance/10||0)]},
    {label:'Valor del inventario',value:money(d.stockValue),icon:'▤',color:'cyan',note:'Stock × costo unitario',spark:[0,0,0,0,0,0,Math.round(d.stockValue/10||0)]},
    {label:'Productos',value:d.products,icon:'▣',color:'blue',note:'Registrados en catálogo',spark:[0,0,0,0,0,0,d.products]},
    {label:'Stock bajo',value:d.lowStock,icon:'!',color:d.lowStock>0?'red':'green',note:'Por debajo del mínimo',spark:[0,0,0,0,0,0,d.lowStock]},
    {label:'Deudas pendientes',value:money(d.outstanding),icon:'◷',color:'orange',note:'Por cobrar a clientes',spark:[0,0,0,0,0,0,Math.round(d.outstanding/10||0)]}
  ];
  let html='<div class="cards">';
  metrics.forEach(m=>{
    html+='<div class="metric metric-card"><div class="metric-head"><span class="metric-icon metric-'+m.color+'">'+m.icon+'</span><div class="metric-badge spark-wrap">'+sparkline(m.spark)+'</div></div><div class="metric-label">'+m.label+'</div><div class="metric-value">'+m.value+'</div><div class="metric-note">'+m.note+'</div></div>';
  });
  html+='</div><div class="panel"><div class="panel-head"><h3>Accesos rápidos</h3></div><div class="quick"><button class="btn primary" onclick="navigate(\'products\')">+ Registrar producto</button><button class="btn primary" onclick="navigate(\'sales\')">+ Registrar venta</button><button class="btn light" onclick="navigate(\'purchases\')">+ Registrar compra</button><button class="btn light" onclick="navigate(\'expenses\')">+ Registrar gasto</button></div></div><div class="panel"><div class="panel-head"><h3>Control del negocio</h3></div><p class="muted">Registra tus productos, controla las entradas y salidas del inventario y administra clientes, proveedores, ventas, compras, gastos y deudas desde el menú lateral.</p></div>';
  $('#view').innerHTML=html;
}
async function renderCrud(view){
  const cfg=configs[view];
  const rows=await api('/'+cfg.endpoint);
  currentRows=rows;
  const state={sort:null,dir:'asc',query:'',page:1,per:12};
  function filtered(){
    let list=rows.slice();
    if(state.query)list=list.filter(r=>cfg.fields.some(f=>String(r[f[0]]??'').toLowerCase().includes(state.query)));
    if(state.sort){const k=state.sort;list.sort((a,b)=>{const av=a[k],bv=b[k],an=Number(av),bn=Number(bv);let cmp;if(av!==''&&bv!==''&&av!=null&&bv!=null&&Number.isFinite(an)&&Number.isFinite(bn))cmp=an-bn;else cmp=String(av??'').localeCompare(String(bv??''),'es',{numeric:true});return state.dir==='asc'?cmp:-cmp;});}
    return list;
  }
  let html='<div class="panel"><div class="panel-head"><h3>Listado de '+cfg.label+'s</h3><div class="toolbar"><input id="filter" placeholder="Buscar..."><button class="btn primary" id="add">+ Nuevo '+cfg.label+'</button></div></div><div class="table-wrap"><table><thead><tr id="thead">';
  const headers=cfg.fields.map(f=>[f[0],f[1]]);headers.unshift(['id','ID']);headers.push(['_actions','Estado / acciones']);
  html+='<tr>'+headers.map(h=>h[0]==='_actions'?'<th>'+h[1]+'</th>':'<th class="sortable" data-sort="'+h[0]+'">'+h[1]+'<span class="sort-ind"></span></th>').join('')+'</tr></thead><tbody id="rows"></tbody></table></div><div id="pager" class="pager"></div></div>';
  $('#view').innerHTML=html;
  function paint(){
    const list=filtered();
    const pages=Math.max(1,Math.ceil(list.length/state.per));
    if(state.page>pages)state.page=pages;
    const slice=list.slice((state.page-1)*state.per,state.page*state.per);
    $('#rows').innerHTML=slice.length?slice.map(r=>rowHtml(view,r)).join(''):'<tr><td colspan="20" class="empty">Sin resultados</td></tr>';
    document.querySelectorAll('#thead th.sortable').forEach(th=>{th.querySelector('.sort-ind').textContent=state.sort===th.dataset.sort?(state.dir==='asc'?'▲':'▼'):'';});
    $('#pager').innerHTML=paginationHtml(state.page,pages,list.length);
    $('#pager').querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{state.page=Number(b.dataset.page);paint();});
    bindRowActions(view);
  }
  $('#add').onclick=()=>openForm(view);
  let t;$('#filter').oninput=e=>{clearTimeout(t);t=setTimeout(()=>{state.query=e.target.value.trim().toLowerCase();state.page=1;paint();},150);};
  document.querySelectorAll('#thead th.sortable').forEach(th=>th.onclick=()=>{const k=th.dataset.sort;if(state.sort===k)state.dir=state.dir==='asc'?'desc':'asc';else{state.sort=k;state.dir='asc';}paint();});
  paint();
}
function paginationHtml(page,pages,total){
  const count='<span class="muted page-total">'+total+' registro'+(total===1?'':'s')+'</span>';
  if(pages<=1)return count;
  let btns='';
  const btn=(p,label,disabled,active)=>'<button class="page-btn'+(active?' active':'')+'"'+(disabled?' disabled':'')+' data-page="'+p+'">'+label+'</button>';
  btns+=btn(page-1,'‹',page<=1,false);
  for(let p=1;p<=pages;p++){if(p===1||p===pages||Math.abs(p-page)<=1)btns+=btn(p,p,false,p===page);else if(Math.abs(p-page)===2)btns+='<span class="page-gap">…</span>';}
  btns+=btn(page+1,'›',page>=pages,false);
  return btns+count;
}
function rowHtml(view,row){
  const cfg=configs[view];let cells='<td>#'+row.id+'</td>';
  cfg.fields.forEach(f=>{let val=row[f[0]];if(['cost','price','salary','amount','paid'].includes(f[0]))val=money(val);cells+='<td>'+esc(val)+'</td>';});
  if(view==='products')cells+='<td><span class="badge '+(Number(row.stock)<=Number(row.min_stock)?'danger':'')+'">'+(Number(row.stock)<=Number(row.min_stock)?'Stock bajo':'Disponible')+'</span> ';
  else cells+='<td>';
  cells+='<div class="actions"><button class="action" data-edit="'+row.id+'">Editar</button><button class="action delete" data-delete="'+row.id+'">Eliminar</button></div></td>';
  return '<tr>'+cells+'</tr>';
}
function bindRowActions(view){
  $('#rows').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openForm(view,currentRows.find(r=>r.id===Number(b.dataset.edit))));
  $('#rows').querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('¿Eliminar este registro?'))return;try{await api('/'+configs[view].endpoint+'/'+b.dataset.delete,{method:'DELETE'});toast('Registro eliminado');render();}catch(e){toast(e.message);}});
}
function openForm(view,row=null){
  editing=row?row.id:null;const cfg=configs[view];$('#modal-title').textContent=(row?'Editar ':'Nuevo ')+cfg.label;$('#modal-fields').innerHTML='';
  cfg.fields.forEach(f=>{const label=document.createElement('label');if(f[0]==='address'||f[0]==='description')label.className='wide';label.innerHTML=esc(f[1])+'<input name="'+f[0]+'" type="'+(f[2]||'text')+'" '+(f[3]?'required':'')+' value="'+esc(row?row[f[0]]??'':'')+'" step="0.01" min="0">';$('#modal-fields').appendChild(label);});
  $('#modal').classList.add('visible');
  $('#modal-form').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target).entries());cfg.fields.forEach(f=>{if(f[2]==='number')data[f[0]]=Number(data[f[0]]||0);});const btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;try{await api('/'+cfg.endpoint+(editing?'/'+editing:''),{method:editing?'PUT':'POST',body:JSON.stringify(data)});$('#modal').classList.add('hidden');toast('Registro guardado correctamente');renderCrud(view);}catch(err){toast(err.message);}finally{btn.disabled=false;}};
}
function closeModal(){$('#modal').classList.remove('visible');}
$('#modal-close').onclick=closeModal;$('#cancel-modal').onclick=closeModal;
let saleItems=[];
function saleTotal(){return saleItems.reduce((t,i)=>t+(i.quantity*i.unit_price),0);}
function renderSaleItems(){
  const list=$('#sale-items');
  if(!list)return;
  list.innerHTML=saleItems.map((i,idx)=>
    '<div class="sale-item-row"><div class="sale-item-name">'+esc(i.name)+'</div><div class="sale-item-meta">'+i.quantity+' × '+money(i.unit_price)+'</div><div class="sale-item-subtotal">'+money(i.subtotal)+'</div><button class="action delete" type="button" onclick="removeSaleItem('+idx+')">×</button></div>'
  ).join('');
  $('#sale-total').textContent=money(saleTotal());
}
function addSaleItem(){
  const select=$('#sale-product');const qty=$('#sale-qty');const price=$('#sale-price');
  const o=select.selectedOptions[0];if(!o)return;
  const productId=Number(o.value);const quantity=Number(qty.value||1);const unitPrice=Number(price.value||o.dataset.price||0);
  const product=o.text;
  if(!quantity||quantity<=0){toast('Cantidad inválida');return;}
  if(quantity>Number(o.dataset.stock||0)){toast('Stock insuficiente');return;}
  const existing=saleItems.findIndex(i=>i.product_id===productId && i.unit_price===unitPrice);
  if(existing>=0){saleItems[existing].quantity+=quantity;saleItems[existing].subtotal=saleItems[existing].quantity*unitPrice;}
  else saleItems.push({product_id:productId,quantity,unit_price:unitPrice,subtotal:quantity*unitPrice,name:product});
  qty.value=1;price.value='';renderSaleItems();
}
function removeSaleItem(idx){saleItems.splice(idx,1);renderSaleItems();}
async function renderSales(){
  const [sales,products,clients]=await Promise.all([api('/sales'),api('/products'),api('/clients')]);
  saleItems=[];
  const productsOptions=products.filter(p=>p.stock>0).map(p=>'<option value="'+p.id+'" data-price="'+p.price+'" data-stock="'+p.stock+'">'+esc(p.name)+' (stock: '+p.stock+')</option>').join('');
  let html='<div class="panel"><div class="panel-head"><h3>Registrar una venta</h3></div><div class="sale-panel"><div class="sale-form-col"><form id="sale-form" class="form-grid"><label>Cliente<select name="client_id"><option value="">Venta sin cliente</option>'+clients.map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('')+'</select></label><div class="sale-add-row"><label style="margin-bottom:0">Producto<select id="sale-product">'+productsOptions+'</select></label><label style="margin-bottom:0">Cantidad<input id="sale-qty" type="number" min="0.01" step="0.01" value="1"></label><label style="margin-bottom:0">Precio (Bs.)<input id="sale-price" type="number" min="0" step="0.01"></label><button class="btn primary" type="button" onclick="addSaleItem()">Agregar</button></div><div id="sale-items-wrap" class="sale-items-wrap"><div class="sale-items-head"><div>Producto</div><div>Cant. × P.Unit.</div><div>Subtotal</div><div></div></div><div id="sale-items" class="sale-items-list"></div></div><div class="sale-total-row"><span>Total:</span><span id="sale-total">Bs. 0,00</span></div><label class="wide">Monto pagado (Bs.)<input name="paid" type="number" min="0" step="0.01" value="0"></label><label class="wide">Notas<input name="notes"></label><div class="wide"><button class="btn primary" type="submit">Registrar venta</button></div></form></div></div></div>';
  html+='<div class="panel"><div class="panel-head"><h3>Historial de ventas</h3></div>'+table(['N.º','Cliente','Total','Pagado','Fecha'],sales.map(s=>[s.id,esc(s.client_name||'Venta directa'),money(s.total),money(s.paid),esc(s.created_at)]))+'</div>';
  $('#view').innerHTML=html;
  const select=$('#sale-product');const setPrice=()=>{const o=select.selectedOptions[0];$('#sale-price').value=o?o.dataset.price:'';};select.onchange=setPrice;setPrice();
  $('#sale-form').onsubmit=async e=>{e.preventDefault();if(!saleItems.length){toast('Agrega al menos un producto.');return;}const fd=new FormData(e.target);const btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;try{await api('/sales',{method:'POST',body:JSON.stringify({client_id:fd.get('client_id')||null,paid:Number(fd.get('paid')),notes:fd.get('notes'),items:saleItems})});toast('Venta registrada y stock actualizado');saleItems=[];renderSales();}catch(err){toast(err.message);}finally{btn.disabled=false;}};
}
async function renderPurchases(){
  const [purchases,products,suppliers]=await Promise.all([api('/purchases'),api('/products'),api('/suppliers')]);
  let html='<div class="panel"><div class="panel-head"><h3>Registrar una compra</h3></div><form id="purchase-form" class="form-grid"><label>Proveedor<select name="supplier_id"><option value="">Sin proveedor</option>'+suppliers.map(s=>'<option value="'+s.id+'">'+esc(s.name)+'</option>').join('')+'</select></label><label>Producto<select id="purchase-product">'+products.map(p=>'<option value="'+p.id+'" data-cost="'+p.cost+'">'+esc(p.name)+'</option>').join('')+'</select></label><label>Cantidad<input id="purchase-qty" type="number" min="0.01" step="0.01" value="1"></label><label>Costo unitario (Bs.)<input id="purchase-cost" type="number" min="0" step="0.01"></label><label class="wide">Notas<input name="notes"></label><div class="wide"><button class="btn primary">Registrar compra</button></div></form></div>';
  html+='<div class="panel"><div class="panel-head"><h3>Historial de compras</h3></div>'+table(['N.º','Proveedor','Total','Fecha'],purchases.map(p=>[p.id,esc(p.supplier_name||'Sin proveedor'),money(p.total),esc(p.created_at)]))+'</div>';
  $('#view').innerHTML=html;const sel=$('#purchase-product');const set=()=>$('#purchase-cost').value=sel.selectedOptions[0]?.dataset.cost||0;sel.onchange=set;set();
  $('#purchase-form').onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target);const btn=e.target.querySelector('button[type="submit"]');btn.disabled=true;try{await api('/purchases',{method:'POST',body:JSON.stringify({supplier_id:fd.get('supplier_id')||null,notes:fd.get('notes'),items:[{product_id:Number(sel.value),quantity:Number($('#purchase-qty').value),unit_cost:Number($('#purchase-cost').value)}]})});toast('Compra registrada y stock actualizado');renderPurchases();}catch(err){toast(err.message);}finally{btn.disabled=false;}};
}
function table(headers,rows){return '<div class="table-wrap"><table><thead><tr>'+headers.map(h=>'<th>'+h+'</th>').join('')+'</tr></thead><tbody>'+(rows.length?rows.map(r=>'<tr>'+r.map(v=>'<td>'+v+'</td>').join('')+'</tr>').join(''):'<tr><td class="empty" colspan="'+headers.length+'">Todavía no hay registros</td></tr>')+'</tbody></table></div>';}
async function renderMovements(){const rows=await api('/inventory/movements');$('#view').innerHTML='<div class="panel"><div class="panel-head"><h3>Últimos movimientos de inventario</h3></div>'+table(['ID','Producto','Movimiento','Cantidad','Detalle','Fecha'],rows.map(r=>[r.id,esc(r.product_name),'<span class="badge '+(r.movement_type==='SALIDA'?'warn':'')+'">'+r.movement_type+'</span>',r.quantity,esc(r.note),esc(r.created_at)]))+'</div>';}
async function renderReports(){const d=await api('/reports/summary');$('#view').innerHTML='<div class="report-grid"><div class="panel"><div class="panel-head"><h3>Ventas por mes</h3></div>'+table(['Mes','Total'],d.byMonth.map(x=>[x.month,money(x.total)]))+'</div><div class="panel"><div class="panel-head"><h3>Gastos por categoría</h3></div>'+table(['Categoría','Total'],d.expenseByCategory.map(x=>[esc(x.category),money(x.total)]))+'</div></div><div class="panel"><div class="panel-head"><h3>Exportación</h3></div><p class="muted">Descarga el inventario actual en formato CSV, compatible con Excel.</p><a class="btn primary" href="/api/export/products.csv" id="csv-download">Descargar inventario CSV</a></div>';$('#csv-download').onclick=async e=>{e.preventDefault();try{const res=await fetch('/api/export/products.csv',{headers:{Authorization:'Bearer '+token}});if(!res.ok)throw new Error('No se pudo exportar el inventario.');const blob=await res.blob();const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='plastinova-productos.csv';a.click();URL.revokeObjectURL(a.href);}catch(err){toast(err.message);}};}
if(token){
  if(tokenExpired(token)){token='';localStorage.removeItem('plastinova_token');showLogin();}
  else{const p=jwtPayload(token)||{};$('#whoami').textContent=p.username||'Administrador';scheduleExpiry(token);showApp();navigate('dashboard');}
}else showLogin();
