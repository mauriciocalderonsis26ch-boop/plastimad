/* ========== PLASTINOVA Landing Animations ========== */

document.addEventListener('DOMContentLoaded', () => {
  // Elementos que se revelan al entrar en el viewport
  const revealTargets = document.querySelectorAll(
    '.hero-content, .hero .badge, .hero h1, .hero .lead, .hero-actions, .hero-stats, .stat, .hero-visual, .section-head, .feature-card, .product-card, .cta'
  );

  revealTargets.forEach((el, i) => {
    el.classList.add('reveal');
    el.style.transitionDelay = Math.min(i * 0.06, 0.3) + 's';
  });

  // Fallback: si el navegador no soporta IntersectionObserver, mostrar todo
  if (!('IntersectionObserver' in window)) {
    revealTargets.forEach((el) => el.classList.add('visible'));
  } else {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

    revealTargets.forEach((el) => observer.observe(el));
  }

  // Contadores animados
  const statNumbers = document.querySelectorAll('.stat-number[data-final]');
  const animateValue = (el, end) => {
    const duration = 1200;
    let startTimestamp = null;
    const step = (timestamp) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      const value = Math.floor(progress * end);
      el.textContent = value + (el.dataset.suffix || '');
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = end + (el.dataset.suffix || '');
    };
    requestAnimationFrame(step);
  };

  if ('IntersectionObserver' in window) {
    const statsObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateValue(entry.target, Number(entry.target.dataset.final) || 0);
          statsObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    statNumbers.forEach((n) => statsObserver.observe(n));
  } else {
    statNumbers.forEach((n) => {
      n.textContent = (n.dataset.final || '0') + (n.dataset.suffix || '');
    });
  }

  // Scroll suave para anclas
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const href = anchor.getAttribute('href');
      if (href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
});
