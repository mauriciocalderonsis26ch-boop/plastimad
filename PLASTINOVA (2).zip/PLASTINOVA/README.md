# PLASTINOVA

Sistema web inicial para administrar una empresa de compra y venta de productos plásticos. Incluye inventario, clientes, proveedores, empleados, ventas, compras, gastos, deudas, movimientos y reportes básicos.

## Requisitos
- Windows 10/11, macOS o Linux.
- Node.js LTS (recomendado Node 20 o 22) y npm.
- Conexión a Internet durante la primera instalación para descargar dependencias.

## Instalación en Windows
1. Extrae `PLASTINOVA.zip`.
2. Abre la carpeta `PLASTINOVA` en Visual Studio Code.
3. Abre Terminal > Nueva terminal.
4. Ejecuta:

```bash
npm install
```

5. Copia `.env.example` y renombra la copia a `.env`. Puedes dejar los valores iniciales para probar.
6. Ejecuta:

```bash
npm run dev
```

7. Abre en el navegador: http://localhost:3000

## Acceso inicial
- Usuario: `admin`
- Contraseña: `Admin123!`

Cambia estas credenciales antes de utilizar el sistema con información real. Para ello, define `ADMIN_USER`, `ADMIN_PASSWORD` y `JWT_SECRET` en `.env` antes del primer arranque. Si ya se creó la base de datos, cambiar esas variables no cambia automáticamente la contraseña del usuario existente.

## Base de datos
El sistema utiliza SQLite. La base de datos se crea automáticamente en `data/plastinova.db` al iniciar el servidor. Haz copias de seguridad periódicas de ese archivo.

## Funciones incluidas
- Panel de resumen: ventas, compras y gastos del día, valor del inventario, alertas de stock bajo y deudas pendientes.
- Productos: alta, edición, eliminación y stock mínimo.
- Clientes, proveedores y empleados.
- Ventas: registro de una línea de producto por operación, validación de stock y descuento automático de inventario.
- Compras: registro de una línea de producto por operación y aumento automático de inventario.
- Gastos y deudas.
- Historial de movimientos de inventario.
- Reportes básicos y exportación del inventario a CSV para abrirlo en Excel.

## Despliegue con Docker (recomendado para producción)

Se incluye un `Dockerfile` de multi-stage build y un `docker-compose.yml` listos para usar.

### Requisitos
- Docker y Docker Compose instalados.
- No necesitas Node.js instalado en la máquina host.

### Pasos

1. Copia el archivo de variables de entorno:
   ```bash
   copy .env.example .env     # Windows (cmd)
   # o en PowerShell:
   Copy-Item .env.example .env
   ```
   Edita `.env` y define al menos `JWT_SECRET`, `ADMIN_USER` y `ADMIN_PASSWORD`.

2. Levanta el contenedor:
   ```bash
   docker compose up -d --build
   ```

3. Abre en el navegador: http://localhost:3000
   (Si cambiaste el puerto en `docker-compose.yml`, usa ese puerto.)

### Comandos útiles

```bash
docker compose up -d        # Iniciar en segundo plano
docker compose down         # Detener y eliminar contenedor
docker compose logs -f      # Ver logs en tiempo real
docker compose up -d --build # Reconstruir imagen tras cambios
docker compose restart      # Reiniciar el servicio
```

### Persistencia de datos

La base de datos SQLite (`data/plastinova.db`) se almacena en el volumen Docker `plastinova_data`, por lo que persiste aunque detengas o elimines el contenedor.

Para hacer una copia de seguridad de la base de datos:
```bash
docker compose exec bmaru cp /app/data/plastinova.db ./backup-plastinova.db
```

### Puerto por defecto

El contenedor escucha en el puerto `3000` y se expone en el host como `3000:3000`. Si ya usas ese puerto en tu máquina, cambia el lado izquierdo en `docker-compose.yml`, por ejemplo `"3311:3000"`.

## Importante

Esta es una primera versión funcional para pruebas y uso local. Antes de usarla como sistema comercial definitivo, se recomienda agregar copias de seguridad automatizadas, permisos por rol, recuperación de contraseña, validación contable, comprobantes, auditoría y pruebas de seguridad. No publiques el servidor directamente en Internet sin configurar HTTPS, credenciales seguras y medidas de protección.
