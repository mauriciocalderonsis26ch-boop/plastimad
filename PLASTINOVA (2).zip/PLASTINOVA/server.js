require('dotenv').config();
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');
const { authRequired } = require('./middleware');
const { loadServices } = require('./services');
const { z } = require('zod');
const {
  ProductSchema,
  ClientSchema,
  SupplierSchema,
  EmployeeSchema,
  ExpenseSchema,
  DebtSchema,
  SaleSchema,
  PurchaseSchema,
  LoginSchema,
} = require('./schemas');
const path = require('path');

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const PORT = Number(process.env.PORT || 3000);

// Servicios del ERP ligero
const services = loadServices(db);

/* ========== Middleware de validación ========== */
function validate(schema) {
  return (req, res, next) => {
    try {
      schema.parse(req.body);
      next();
    } catch (err) {
      if (err instanceof z.ZodError) {
        const mensajes = (err.errors || []).map((e) => `${e.path.join('.')}: ${e.message}`);
        return res.status(400).json({ error: mensajes.join('; ') });
      }
      next(err);
    }
  };
}

/* ========== Helper: envolver rutas async/sync en try/catch ========== */
function safeHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch((err) => next(err));
  };
}

/* ========== Auth ========== */
app.post('/api/login', validate(LoginSchema), safeHandler((req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '12h' });
  res.json({ token, user: { id: user.id, username: user.username, role: user.role } });
}));

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'Bmaru' }));
app.use('/api', authRequired);

/* ========== Rutas CRUD genéricas (entidades simples) ========== */
function crudRoute(route, serviceName) {
  const svc = services[serviceName];

  app.get('/api/' + route, safeHandler((req, res) => {
    res.json(svc.list());
  }));

  app.post('/api/' + route, validate(getCreateSchema(route)), safeHandler((req, res) => {
    const created = svc.create(req.body);
    res.status(201).json(created);
  }));

  app.put('/api/' + route + '/:id', validate(getUpdateSchema(route)), safeHandler((req, res) => {
    const updated = svc.update(req.params.id, req.body);
    res.json(updated);
  }));

  app.delete('/api/' + route + '/:id', safeHandler((req, res) => {
    svc.remove(req.params.id);
    res.json({ ok: true });
  }));
}

function getCreateSchema(route) {
  const map = {
    products: ProductSchema,
    clients: ClientSchema,
    suppliers: SupplierSchema,
    employees: EmployeeSchema,
    expenses: ExpenseSchema,
    debts: DebtSchema,
  };
  return map[route] || ProductSchema;
}

function getUpdateSchema(route) {
  const base = getCreateSchema(route);
  return base.partial();
}

crudRoute('products', 'products');
crudRoute('clients', 'clients');
crudRoute('suppliers', 'suppliers');
crudRoute('employees', 'employees');
crudRoute('expenses', 'expenses');
crudRoute('debts', 'debts');

/* ========== Ventas ========== */
app.get('/api/sales', safeHandler((req, res) => {
  res.json(services.sales.list());
}));

app.get('/api/sales/:id/items', safeHandler((req, res) => {
  res.json(services.sales.getItems(req.params.id));
}));

app.post('/api/sales', validate(SaleSchema), safeHandler((req, res) => {
  const id = services.sales.create(req.body);
  res.status(201).json(services.sales.getById(id));
}));

/* ========== Compras ========== */
app.get('/api/purchases', safeHandler((req, res) => {
  res.json(services.purchases.list());
}));

app.post('/api/purchases', validate(PurchaseSchema), safeHandler((req, res) => {
  const id = services.purchases.create(req.body);
  res.status(201).json(services.purchases.getById(id));
}));

/* ========== Dashboard ========== */
app.get('/api/dashboard', safeHandler((req, res) => {
  res.json(services.dashboard.getSummary());
}));

/* ========== Reportes ========== */
app.get('/api/reports/summary', safeHandler((req, res) => {
  res.json(services.reports.getSummary());
}));

/* ========== Movimientos ========== */
app.get('/api/inventory/movements', safeHandler((req, res) => {
  res.json(services.movements.list());
}));

/* ========== Exportación ========== */
app.get('/api/export/products.csv', safeHandler((req, res) => {
  const csv = services.export.getProductsCsv();
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="bmaru-productos.csv"');
  res.send(csv);
}));

/* ========== Health ========== */


/* ========== Vistas ========== */
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'landing.html')));
app.get('/app', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

/* ========== SPA fallback ========== */
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

/* ========== Middleware de errores global ========== */
app.use((err, req, res, next) => {
  console.error('[Bmaru] Error:', err.message);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({ error: err.message || 'Error interno del servidor' });
});

/* ========== Evitar que el proceso se caiga por promesas no capturadas ========== */
process.on('unhandledRejection', (reason) => {
  console.error('[Bmaru] UnhandledRejection:', reason);
});

app.listen(PORT, () => {
  console.log('\nBmaru ERP está funcionando: http://localhost:' + PORT);
  console.log('Usuario inicial: ' + (process.env.ADMIN_USER || 'admin'));
});
