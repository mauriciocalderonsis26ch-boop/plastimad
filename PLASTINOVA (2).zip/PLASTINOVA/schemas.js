const { z } = require('zod');

/* ========== Esquemas de validación — Bmaru ERP Ligero ========== */

const BaseEntitySchema = z.object({
  name: z.string().min(1, 'El nombre es obligatorio').max(100),
});

const ProductSchema = z.object({
  name: z.string().min(1, 'Nombre requerido').max(100),
  category: z.string().max(50).optional().default(''),
  unit: z.string().max(30).optional().default('unidad'),
  cost: z.number().min(0, 'El costo no puede ser negativo').optional().default(0),
  price: z.number().min(0, 'El precio no puede ser negativo').optional().default(0),
  stock: z.number().min(0, 'El stock no puede ser negativo').optional().default(0),
  min_stock: z.number().min(0, 'El stock mínimo no puede ser negativo').optional().default(0),
  active: z.boolean().optional().default(true),
});

const ClientSchema = z.object({
  name: z.string().min(1, 'Nombre requerido').max(100),
  phone: z.string().max(30).optional().default(''),
  email: z.string().email('Correo inválido').max(100).optional().default(''),
  address: z.string().max(200).optional().default(''),
});

const SupplierSchema = ClientSchema;

const EmployeeSchema = z.object({
  name: z.string().min(1, 'Nombre requerido').max(100),
  position: z.string().max(100).optional().default(''),
  phone: z.string().max(30).optional().default(''),
  salary: z.number().min(0, 'Salario inválido').optional().default(0),
});

const ExpenseSchema = z.object({
  description: z.string().min(1, 'Descripción requerida').max(200),
  category: z.string().max(50).optional().default('General'),
  amount: z.number().min(0, 'Importe inválido'),
});

const DebtSchema = z.object({
  person: z.string().min(1, 'Persona requerida').max(100),
  description: z.string().max(200).optional().default(''),
  amount: z.number().min(0, 'Monto inválido'),
  paid: z.number().min(0, 'Pagado inválido').optional().default(0),
  due_date: z.string().optional().default(''),
});

const SaleItemSchema = z.object({
  product_id: z.number().int().positive('Producto inválido'),
  quantity: z.number().min(0.01, 'Cantidad debe ser mayor a 0'),
  unit_price: z.number().min(0, 'Precio inválido'),
});

const SaleSchema = z.object({
  client_id: z.number().int().positive().optional().nullable(),
  paid: z.number().min(0, 'Pagado inválido').default(0),
  notes: z.string().max(500).optional().default(''),
  items: z.array(SaleItemSchema).min(1, 'Agrega al menos un producto'),
});

const PurchaseItemSchema = z.object({
  product_id: z.number().int().positive('Producto inválido'),
  quantity: z.number().min(0.01, 'Cantidad debe ser mayor a 0'),
  unit_cost: z.number().min(0, 'Costo inválido'),
});

const PurchaseSchema = z.object({
  supplier_id: z.number().int().positive().optional().nullable(),
  notes: z.string().max(500).optional().default(''),
  items: z.array(PurchaseItemSchema).min(1, 'Agrega al menos un producto'),
});

const LoginSchema = z.object({
  username: z.string().min(1, 'Usuario requerido'),
  password: z.string().min(1, 'Contraseña requerida'),
});

module.exports = {
  z,
  ProductSchema,
  ClientSchema,
  SupplierSchema,
  EmployeeSchema,
  ExpenseSchema,
  DebtSchema,
  SaleSchema,
  SaleItemSchema,
  PurchaseSchema,
  PurchaseItemSchema,
  LoginSchema,
};
